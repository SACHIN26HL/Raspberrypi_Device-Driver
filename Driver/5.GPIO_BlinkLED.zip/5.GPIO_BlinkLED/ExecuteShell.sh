make clean

make

rm *.mod

rm *.o
rm *.symvers
rm *.order








